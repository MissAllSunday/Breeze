Breeze mod for SMF

Breeze mod is intended to replace the dull default profile summary with a new one.

Features:
-Status
-Comments


Requeriments:
-SMF 2.0.x
-PHP 5.3

This mod uses the following scripts:

-Srinivas Tamada's notification plugin http://www.9lessons.info/2011/10/jquery-notification-plugin.html
-Nadia Alramli's confirm plugin http://nadiana.com/jquery-confirm-plugin
-Facebox https://github.com/defunkt/facebox
-zRSSFeeds http://www.zazar.net/developers/jquery/zrssfeed/
-Brandon Aaron's Live query plugin http://brandonaaron.net/code/livequery/docs